import defaultPic from "../images/example.png";

function DefaultProfilePic({ altText }) {
	return <img src={defaultPic} alt={altText} />;
}

export default DefaultProfilePic;