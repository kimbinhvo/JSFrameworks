import Heading from '../layout/Heading';

export default function Contact() {
  return <Heading title="Contact" />;
}