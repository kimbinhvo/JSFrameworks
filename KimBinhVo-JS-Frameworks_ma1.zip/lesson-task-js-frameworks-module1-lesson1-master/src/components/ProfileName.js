import React from "react";

function ProfileName(props) {
    return <h4>{props.name} </h4>
}

export default ProfileName;


