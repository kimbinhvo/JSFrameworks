import Heading from '../layout/Heading';

export default function Home() {
  
  return <Heading title="Home" />;
}