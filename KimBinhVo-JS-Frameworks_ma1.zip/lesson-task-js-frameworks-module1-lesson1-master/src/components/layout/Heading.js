import React from "react";

function Heading(title) {
    return <h4>{title} </h4>
}

export default Heading;


