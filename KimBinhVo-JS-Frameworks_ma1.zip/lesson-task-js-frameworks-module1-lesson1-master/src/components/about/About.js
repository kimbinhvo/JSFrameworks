import Heading from '../layout/Heading';


export default function About() {
  return (
    <>
      <Heading title="About" />
      <p>This is the about page</p>
    </>
  );
}