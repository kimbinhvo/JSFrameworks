import './sass/style.scss';
import Layout from './components/layout/Layout';



function App() {
  return (
    <div>
      <Layout />
    </div>
  );
}

export default App;
